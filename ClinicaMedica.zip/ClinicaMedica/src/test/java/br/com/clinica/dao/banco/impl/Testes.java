/*
 * To change this license header; choose License Headers in Project Properties.
 * To change this template file; choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.clinica.dao.banco.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.junit.Ignore;
import org.junit.Test;

/**
 *
 * @author Henrique Baron
 */
public class Testes {

    public static String nomeAleatorio() {
        List<String> nomes = new ArrayList();
        nomes.add("Micah Whitley");
        nomes.add("Brady Newton");
        nomes.add("Aaron Rice");
        nomes.add("Hope Gilbert");
        nomes.add("Omar Brady");
        nomes.add("Vincent Solomon");
        nomes.add("Ruth Mckee");
        nomes.add("Kiona Dudley");
        nomes.add("Mariko Goodman");
        nomes.add("Ava Ball");
        nomes.add("Wanda Lloyd");
        nomes.add("Daniel Wyatt");
        nomes.add("Martina Singleton");
        nomes.add("Julian Goodman");
        nomes.add("Palmer Jordan");
        nomes.add("Timon Blankenship");
        nomes.add("Shaeleigh Leonard");
        nomes.add("Ria Richard");
        nomes.add("Bert Strong");
        nomes.add("Zephania Wall");
        nomes.add("Molly Fox");
        nomes.add("Brennan Lopez");
        nomes.add("Nevada Rodgers");
        nomes.add("Price Vazquez");
        nomes.add("Brennan Duke");
        nomes.add("Jenna Robinson");
        nomes.add("Brynn Mclaughlin");
        nomes.add("Bree Rowland");
        nomes.add("Shad Melendez");
        nomes.add("Prescott Lambert");
        nomes.add("Piper Workman");
        nomes.add("Gavin Farley");
        nomes.add("Gage Horn");
        nomes.add("Cruz Koch");
        nomes.add("Hadassah Fowler");
        nomes.add("Denton Ramos");
        nomes.add("Wynter Guerrero");
        nomes.add("Rhiannon Deleon");
        nomes.add("Kennedy Bishop");
        nomes.add("Vincent Guthrie");
        nomes.add("Erin Walker");
        nomes.add("Iona Ramsey");
        nomes.add("Tucker Church");
        nomes.add("Jerry Porter");
        nomes.add("Madonna Taylor");
        nomes.add("Natalie Dodson");
        nomes.add("Victoria Hatfield");
        nomes.add("Jarrod Decker");
        nomes.add("Maggie Barry");
        nomes.add("Jemima Adams");
        nomes.add("Leigh Ray");
        nomes.add("Zephania Moreno");
        nomes.add("Blossom Marquez");
        nomes.add("Jonas Aguirre");
        nomes.add("Merritt Lane");
        nomes.add("Declan Salas");
        nomes.add("Lara Livingston");
        nomes.add("Katell Reilly");
        nomes.add("Beverly Woods");
        nomes.add("Xanthus Duke");
        nomes.add("Owen Hudson");
        nomes.add("Josiah Gibson");
        nomes.add("Amity Le");
        nomes.add("Herman Hartman");
        nomes.add("Hilary Roach");
        nomes.add("Hayes Mullen");
        nomes.add("Charissa Elliott");
        nomes.add("Nasim Dawson");
        nomes.add("Hilda Vaughan");
        nomes.add("Arsenio Mcgee");
        nomes.add("Timothy Pope");
        nomes.add("Piper Chavez");
        nomes.add("Martena Whitfield");
        nomes.add("Uriel Valencia");
        nomes.add("Sopoline Heath");
        nomes.add("Rosalyn Melendez");
        nomes.add("Clinton Gutierrez");
        nomes.add("Maggie Levy");
        nomes.add("Karyn Holman");
        nomes.add("Octavius Cooper");
        nomes.add("Reagan Summers");
        nomes.add("Rafael Griffin");
        nomes.add("Daphne Morgan");
        nomes.add("Chester Zamora");
        nomes.add("Xenos Walton");
        nomes.add("Daniel Dean");
        nomes.add("Hoyt Cantrell");
        nomes.add("Medge Jensen");
        nomes.add("Anthony Shannon");
        nomes.add("Dieter Bonner");
        nomes.add("Orson Reynolds");
        nomes.add("Mercedes Ruiz");
        nomes.add("Lewis Price");
        nomes.add("Chester Miranda");
        nomes.add("Xandra Leonard");
        nomes.add("Macy Snider");
        nomes.add("Rylee Salas");
        nomes.add("Yardley Price");
        nomes.add("Deirdre Jacobs");
        nomes.add("Macon Ferguson");
        return nomes.get(new Random().nextInt(nomes.size()));
    }
}
