package br.com.clinica.dao.banco.impl;

import br.com.clinica.dao.banco.GenericDAO;
import br.com.clinica.domain.Endereco;


public class EnderecoDaoImpl extends GenericDAO<Endereco> {


}
