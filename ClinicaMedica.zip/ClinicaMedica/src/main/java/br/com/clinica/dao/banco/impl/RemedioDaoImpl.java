package br.com.clinica.dao.banco.impl;

import br.com.clinica.dao.banco.GenericDAO;
import br.com.clinica.domain.Remedio;


public class RemedioDaoImpl extends GenericDAO<Remedio> {



}
