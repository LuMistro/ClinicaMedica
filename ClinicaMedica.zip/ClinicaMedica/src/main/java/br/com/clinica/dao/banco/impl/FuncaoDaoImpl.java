package br.com.clinica.dao.banco.impl;

import br.com.clinica.dao.banco.GenericDAO;
import br.com.clinica.domain.Funcao;

public class FuncaoDaoImpl extends GenericDAO<Funcao> {

}
