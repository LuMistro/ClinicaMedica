package br.com.clinica.dao.banco.impl;

import br.com.clinica.dao.banco.GenericDAO;
import br.com.clinica.domain.Doenca;


public class DoencaDaoImpl extends GenericDAO<Doenca> {

}
